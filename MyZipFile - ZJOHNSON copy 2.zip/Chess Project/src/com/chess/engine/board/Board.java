package com.chess.engine.board;

public class Board {

	public ChessTile getTile(final int tileCoordinate) {
		return null;
	}
}
