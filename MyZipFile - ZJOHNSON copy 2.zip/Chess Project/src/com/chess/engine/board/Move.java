package com.chess.engine.board;

import com.chess.engine.pieces.Piece;

public abstract class Move {

	final Board board;
	final Piece movedPiece;
	final int destinationCoordinate;
	
	private Move(final Board board, final Piece movedPiece, final int destinationCoordiante) {
		this.board = board;
		this.movedPiece = movedPiece;
		this.destinationCoordinate = destinationCoordiante;
	}
	
	public static final class MajorMove extends Move {

		public MajorMove(final Board board, final Piece movedPiece, final int destinationCoordiante) {
			super(board, movedPiece, destinationCoordiante);
			// TODO Auto-generated constructor stub
		}
		
	}
	
	public static final class AttackMove extends Move {
		
		final Piece attackedPiece;

		public AttackMove(final Board board, final Piece movedPiece, final int destinationCoordiante,
				final Piece attackedPiece) {
			super(board, movedPiece, destinationCoordiante);
			this.attackedPiece = attackedPiece;
			// TODO Auto-generated constructor stub
		}
		
	}
	
}
