package com.chess.engine.pieces;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import com.chess.engine.Alliance;
import com.chess.engine.board.Board;
import com.chess.engine.board.BoardUtils;
import com.chess.engine.board.ChessTile;
import com.chess.engine.board.Move;

public class King extends Piece {
	
	private final static int[] CANIDATE_MOVE_COORDINATE = {-9, -8, -7, -1, 1, 7, 8, 9};


	King(int piecePosition, Alliance pieceAlliance) {
		super(piecePosition, pieceAlliance);
		// TODO Auto-generated constructor stub
	}

	@Override
	public Collection<Move> calculateLegalMoves(Board board) {
		// TODO Auto-generated method stub
		final List<Move> legalMoves = new ArrayList<>();
		
		for(final int currentCanidateOffset: CANIDATE_MOVE_COORDINATE) {
			final int canidateDesCor = this.piecePosition + currentCanidateOffset;
			if() {
				continue;
			}
			if(BoardUtils.isValidTileCoordinate(canidateDesCor)) {
				final ChessTile canidateDesCorTile = board.getTile(canidateDesCor);
				if(!canidateDesCorTile.isTileOccupied()) {
					legalMoves.add(new Move.MajorMove(board, this, canidateDesCor));
				}
				else {
					final Piece pieceAtDestination = canidateDesCorTile.getPiece();
					final Alliance pieceAlliance = pieceAtDestination.getPieceAlliance();

					if(this.pieceAlliance != pieceAlliance) {
						legalMoves.add(new Move.AttackMove(board, this, canidateDesCor, pieceAtDestination));
					}
				}
			}
		}
	
		return Collections.unmodifiableList(legalMoves);
	}
	
	private static boolean isFirstColExclu(final int currentPosition, final int canidateOffset) {

		return BoardUtils.FIRST_COLUMN[currentPosition] && (canidateOffset == -17 || 
				canidateOffset == -10 || canidateOffset == 6 || canidateOffset == 15);
	}
	
	private static boolean isEighthColEclu(final int currentPosition, final int canidateOffset) {
		return BoardUtils.EIGHTH_COLUMN[currentPosition] && (canidateOffset == -10 ||
				canidateOffset == 6);
	}

}
