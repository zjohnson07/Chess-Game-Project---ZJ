package com.chess.engine.pieces;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import com.chess.engine.Alliance;
import com.chess.engine.board.Board;
import com.chess.engine.board.BoardUtils;
import com.chess.engine.board.ChessTile;
import com.chess.engine.board.Move;

public class Rook extends Piece {
	
	private static final int[] CANIDATE_MOVE_VECTOR_COORDINATES = { -8, -1, 1, 8};

	Rook(int piecePosition, Alliance pieceAlliance) {
		super(piecePosition, pieceAlliance);
		// TODO Auto-generated constructor stub
	}

	@Override
	public Collection<Move> calculateLegalMoves(final Board board) {
		// TODO Auto-generated method stub

		final List<Move> legalMoves = new ArrayList<>();

		for (final int canidateCoordinateOffset: CANIDATE_MOVE_VECTOR_COORDINATES) {
			int  canidateDesCor = this.piecePosition;
			while(BoardUtils.isValidTileCoordinate(canidateDesCor)) {
				if(isFirstColExclu(canidateDesCor, canidateCoordinateOffset) || 
						isEighthColExclu(canidateDesCor, canidateCoordinateOffset)) {
					break;
				}
				canidateDesCor += canidateCoordinateOffset;
				if(BoardUtils.isValidTileCoordinate(canidateDesCor)) {
					final ChessTile canidateDesCorTile = board.getTile(canidateDesCor);
					if(!canidateDesCorTile.isTileOccupied()) {
						legalMoves.add(new Move.MajorMove(board, this, canidateDesCor));
					}
					else {
						final Piece pieceAtDestination = canidateDesCorTile.getPiece();
						final Alliance pieceAlliance = pieceAtDestination.getPieceAlliance();

						if(this.pieceAlliance != pieceAlliance) {
							legalMoves.add(new Move.AttackMove(board, this, canidateDesCor, pieceAtDestination));
						}
						break;
					}
				}
			}
		}
		return Collections.unmodifiableList(legalMoves);
	}

	private static boolean isFirstColExclu(final int currentPosition, final int canidateOffset) {
		return BoardUtils.FIRST_COLUMN[currentPosition] && (canidateOffset == -1);
	}
	private static boolean isEighthColExclu(final int currentPosition, final int canidateOffset) {
		return BoardUtils.EIGHTH_COLUMN[currentPosition] && (canidateOffset == 1);
	}
}
