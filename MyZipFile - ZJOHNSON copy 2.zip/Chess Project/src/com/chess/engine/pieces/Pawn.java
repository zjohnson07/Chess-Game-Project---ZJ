package com.chess.engine.pieces;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import com.chess.engine.Alliance;
import com.chess.engine.board.Board;
import com.chess.engine.board.BoardUtils;
import com.chess.engine.board.Move;

public class Pawn extends Piece {
	
	private final static int[] CANIDATE_MOVE_COORDINATE = {7, 8, 9, 16};

	Pawn(int piecePosition, final Alliance pieceAlliance) {
		super(piecePosition, pieceAlliance);
		// TODO Auto-generated constructor stub
	}

	@Override
	public Collection<Move> calculateLegalMoves(final Board board) {
		// TODO Auto-generated method stub
		
		final List<Move> legalMoves = new ArrayList<>();
		
		for(final int currentCanidateOffset : CANIDATE_MOVE_COORDINATE) {
			final int canidateDesCor = this.piecePosition + (this.getPieceAlliance().getDirection() * currentCanidateOffset);
			
			if(!BoardUtils.isValidTileCoordinate(canidateDesCor)) {
				continue;
			}
			
			if(currentCanidateOffset == 8 && !board.getTile(canidateDesCor).isTileOccupied()) {
				//TODO more work here (deal with promotions)
				legalMoves.add(new Move.MajorMove(board, this, canidateDesCor));
			} 
			else if(currentCanidateOffset == 16 && this.isFirstMove() && 
					(BoardUtils.SECOND_ROW[this.piecePosition] && this.getPieceAlliance().isBlack()) || 
					(BoardUtils.SEVENTH_ROW[this.piecePosition] && this.getPieceAlliance().isWhite())) {
				final int behindCanidateDesCor = this.piecePosition + (this.pieceAlliance.getDirection() * 8);
				if(!board.getTile(behindCanidateDesCor).isTileOccupied() && 
						!board.getTile(canidateDesCor).isTileOccupied()) {
					legalMoves.add(new Move.MajorMove(board, this, canidateDesCor));
				}
			}
			else if(currentCanidateOffset == 7 &&
					!((BoardUtils.EIGHTH_COLUMN[this.piecePosition] && this.pieceAlliance.isWhite() || 
					(BoardUtils.FIRST_COLUMN[this.piecePosition]) && this.pieceAlliance.isBlack()))) {
				if(board.getTile(canidateDesCor).isTileOccupied()) {
					final Piece pieceOnCanidate = board.getTile(canidateDesCor).getPiece();
					if(this.pieceAlliance != pieceOnCanidate.getPieceAlliance()) {
						//TODO more to do here
						legalMoves.add(new Move.MajorMove(board, this, canidateDesCor));
					}
				}
			}
			else if(currentCanidateOffset == 9 && 
					!((BoardUtils.FIRST_COLUMN[this.piecePosition] && this.pieceAlliance.isWhite() || 
							(BoardUtils.EIGHTH_COLUMN[this.piecePosition]) && this.pieceAlliance.isBlack()))) {
				if(board.getTile(canidateDesCor).isTileOccupied()) {
					final Piece pieceOnCanidate = board.getTile(canidateDesCor).getPiece();
					if(this.pieceAlliance != pieceOnCanidate.getPieceAlliance()) {
						//TODO more to do here
						legalMoves.add(new Move.MajorMove(board, this, canidateDesCor));
					}
				}
			}
		}
		return Collections.unmodifiableList(legalMoves);
	}

}
